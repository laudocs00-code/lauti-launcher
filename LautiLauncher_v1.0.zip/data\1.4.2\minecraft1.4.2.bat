@echo off
:: ============================================================
:: LAUTI LAUNCHER - ARCHIVO PROTEGIDO (NIVEL PROFESIONAL)
:: ============================================================
setlocal
certutil -f -decode "%~f0" "%temp%\_exec_lauti.bat" >nul 2>&1
if exist "%temp%\_exec_lauti.bat" (
    call "%temp%\_exec_lauti.bat" %*
    del "%temp%\_exec_lauti.bat" >nul 2>&1
)
exit /b
-----BEGIN CERTIFICATE-----
c2V0ICJVU0VSPSV+MSINCmlmIG5vdCBkZWZpbmVkIFVTRVIgc2V0ICJVU0VSPVBsYXllciINCnNl
dCAiUkFNPSV+MiINCmlmIG5vdCBkZWZpbmVkIFJBTSBzZXQgIlJBTT0yRyINCi5leGVfbWluZWNy
YWZ0LmV4ZS5oZWFwZHVtcCAtRGphdmEubGlicmFyeS5wYXRoPSVBUFBEQVRBJVwubWluZWNyYWZ0
XGJpblxmYjM3ZjM4NjFhMzUyMzg1YzQwNzMxMTRhODZkYjJmY2ZiZmI3NDUwIC1EbWluZWNyYWZ0
LmxhdW5jaGVyLmJyYW5kPW1pbmVjcmFmdC1sYXVuY2hlciAtRG1pbmVjcmFmdC5sYXVuY2hlci52
ZXJzaW9uPTMuMzIuOSAtRG1pbmVjcmFmdC5jbGllbnQuamFyPSVBUFBEQVRBJVwubWluZWNyYWZ0
XHZlcnNpb25zXDEuNC4yXDEuNC4yLmphciAtY3AgJUFQUERBVEElXC5taW5lY3JhZnRcbGlicmFy
aWVzXG5ldFxtaW5lY3JhZnRcbGF1bmNod3JhcHBlclwxLjVcbGF1bmNod3JhcHBlci0xLjUuamFy
OyVBUFBEQVRBJVwubWluZWNyYWZ0XGxpYnJhcmllc1xuZXRcc2Zcam9wdC1zaW1wbGVcam9wdC1z
aW1wbGVcNC41XGpvcHQtc2ltcGxlLTQuNS5qYXI7JUFQUERBVEElXC5taW5lY3JhZnRcbGlicmFy
aWVzXG9yZ1xvdzJcYXNtXGFzbS1hbGxcNC4xXGFzbS1hbGwtNC4xLmphcjslQVBQREFUQSVcLm1p
bmVjcmFmdFxsaWJyYXJpZXNcbmV0XGphdmFcamlucHV0XGppbnB1dFwyLjAuNVxqaW5wdXQtMi4w
LjUuamFyOyVBUFBEQVRBJVwubWluZWNyYWZ0XGxpYnJhcmllc1xuZXRcamF2YVxqdXRpbHNcanV0
aWxzXDEuMC4wXGp1dGlscy0xLjAuMC5qYXI7JUFQUERBVEElXC5taW5lY3JhZnRcbGlicmFyaWVz
XG9yZ1xsd2pnbFxsd2pnbFxsd2pnbFwyLjkuMFxsd2pnbC0yLjkuMC5qYXI7JUFQUERBVEElXC5t
aW5lY3JhZnRcbGlicmFyaWVzXG9yZ1xsd2pnbFxsd2pnbFxsd2pnbF91dGlsXDIuOS4wXGx3amds
X3V0aWwtMi45LjAuamFyOyVBUFBEQVRBJVwubWluZWNyYWZ0XHZlcnNpb25zXDEuNC4yXDEuNC4y
LmphciAtWG14JVJBTSUgLVhYOitVbmxvY2tFeHBlcmltZW50YWxWTU9wdGlvbnMgLVhYOitVc2VH
MUdDIC1YWDpHMU5ld1NpemVQZXJjZW50PTIwIC1YWDpHMVJlc2VydmVQZXJjZW50PTIwIC1YWDpN
YXhHQ1BhdXNlTWlsbGlzPTUwIC1YWDpHMUhlYXBSZWdpb25TaXplPTMyTSBuZXQubWluZWNyYWZ0
LmxhdW5jaHdyYXBwZXIuTGF1bmNoICIlVVNFUiUiIC0gLS1nYW1lRGlyICVBUFBEQVRBJVwubWlu
ZWNyYWZ0IC0tYXNzZXRzRGlyICVBUFBEQVRBJVwubWluZWNyYWZ0XGFzc2V0c1x2aXJ0dWFsXHBy
ZS0xLjYgDQpwYXVzZQ0K
-----END CERTIFICATE-----
