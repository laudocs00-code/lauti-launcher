@echo off
setlocal enabledelayedexpansion
title Lauti Launcher - CLOUD EDITION
color 0B
cd /d "%~dp0"

:: Ocultar carpetas internas automaticamente
attrib +h +s "%~dp0data" /s /d >nul 2>nul
:: ============================================================
:: CONFIGURACION INICIAL (FIREBASE)
:: ============================================================
set "RAM_MAX=8G"
set "VERSION=3.0.0-CLOUD"

:: URL de tu Firebase (MANDATORIO: Debes crear tu proyecto en firebase.google.com)
:: Ejemplo: https://mi-proyecto-default-rtdb.firebaseio.com
set "FIREBASE_URL=https://lautilauncher-default-rtdb.firebaseio.com/"

:: Asegurar carpetas base
if not exist data\config mkdir data\config

:: Cargar programas desde programs.txt
:reload_progs
set total_progs=0
for /f "tokens=1,2,3 delims=|" %%A in (data\programs.txt) do (
    if not "%%C"=="" (
        set /a total_progs+=1
        set "progId[!total_progs!]=%%A"
        set "progPath[!total_progs!]=%%B"
        set "progName[!total_progs!]=%%C"
        set "execPath[%%A]=%%B"
    )
)

:: ============================================================
:: PANTALLA DE BIENVENIDA (SPLASH)
:: ============================================================
:splash
cls
echo.
echo      _               _   _   _                             _                
echo     ^| ^|             ^| ^| (_) ^| ^|                           ^| ^|               
echo     ^| ^|  __ _  _   _^| ^|_ _  ^| ^|     __ _ _   _ _ __   ___^| ^|__   ___ _ __  
echo     ^| ^| / _` ^|^| ^| ^| ^| __^| ^| ^| ^|    / _` ^| ^| ^| ^| '_ \ / __^| '_ \ / _ \ '__^| 
echo     ^| ^|^| (_^| ^|^| ^|_^| ^| ^|_^| ^| ^| ^|___^| (_^| ^| ^|_^| ^| ^| ^| ^| (__^| ^| ^| ^|  __/ ^|    
echo     ^|_^| \__,_^| \__,_^|\__^|_^| ^|______\__,_^|\__,_^|_^| ^|_^|\___^|_^| ^|_^|\___^|_^|    
echo.
echo               -- EL LANZADOR DEFINITIVO PARA MINECRAFT -- 
echo.
echo      [1] REGISTRARSE    [2] INICIAR SESION    [0] SALIR
echo.
echo   ----------------------------------------------------------------------
set "choice="
set /p "choice= SELECCION: "

if "!choice!"=="1" goto register
if "!choice!"=="2" goto login
if "!choice!"=="0" exit
goto splash

:: ============================================================
:: MODULO DE REGISTRO
:: ============================================================
:register
cls
echo.
echo          [ REGISTRO CLOUD ]
echo   ----------------------------------------
set "user_reg="
set /p "user_reg=  NUEVO USUARIO : "
set "user_reg=!user_reg: =!"
set "user_reg=!user_reg:"=!"

if "!user_reg!"=="" goto register

:: --- 1. Verificacion Mojang (Bloqueo Premium) ---
echo.
echo    [INFO] Verificando en Mojang...
curl -s "https://api.mojang.com/users/profiles/minecraft/!user_reg!" > "%TEMP%\mojang.json"
powershell -Command "$r = Get-Content '%TEMP%\mojang.json' -Raw; if ($r -like '*id*') { exit 1 } else { exit 0 }"
if !errorlevel! equ 1 (
    echo.
    echo    [!] Error: "!user_reg!" es una cuenta PREMIUM.
    echo    [!] Elige un nombre que no exista en el Minecraft original.
    pause
    goto register
)

:: --- 2. Verificacion Duplicado en Firebase ---
echo    [INFO] Verificando disponibilidad en la nube...
curl -s "!FIREBASE_URL!/users/!user_reg!.json" > "%TEMP%\check.json"
powershell -Command "$r = Get-Content '%TEMP%\check.json' -Raw; if ($r -ne 'null') { exit 1 } else { exit 0 }"
if !errorlevel! equ 1 (
    echo.
    echo    [!] Error: El usuario "!user_reg!" ya existe.
    pause
    goto register
)

:register_pass
set "pass_reg="
set /p "pass_reg=  NUEVA CLAVE     : "
set "pass_reg=!pass_reg: =!"
if "!pass_reg!"=="" goto register_pass

set "pass_conf="
set /p "pass_conf=  CONFIRMAR CLAVE : "
if not "!pass_reg!"=="!pass_conf!" (
    echo.
    echo    [!] Error: Las claves no coinciden.
    pause
    goto register_pass
)

:: --- 3. Guardar en Firebase ---
echo.
echo    [INFO] Sincronizando con la nube...
curl -s -X PUT -d "{\"pass\":\"!pass_reg!\"}" "!FIREBASE_URL!/users/!user_reg!.json" > nul

echo.
echo    [OK] Usuario "!user_reg!" registrado en la nube con exito.
pause
goto splash

:: ============================================================
:: MODULO DE LOGIN
:: ============================================================
:login
cls
echo.
echo          [ INICIO DE SESION CLOUD ]
echo   ----------------------------------------
set "user_in="
set "pass_in="
set /p "user_in=  USUARIO : "
set /p "pass_in=  CLAVE   : "

set "user_in=!user_in: =!"
set "pass_in=!pass_in: =!"

if "!user_in!"=="" goto splash

echo.
echo    [INFO] Validando credenciales en la nube...
curl -s "!FIREBASE_URL!/users/!user_in!.json" > "%TEMP%\login.json"
powershell -Command "$r = Get-Content '%TEMP%\login.json' -Raw | ConvertFrom-Json; if ($r.pass -eq '!pass_in!') { exit 0 } else { exit 1 }"
if !errorlevel! equ 0 (
    set "saveduser=!user_in!"
    echo.
    echo    [OK] Bienvenido, !saveduser!.
    timeout /t 1 >nul
    goto launcher
)

echo.
echo    [ERROR] Usuario o clave incorrectos.
pause
goto splash

:: ============================================================
:: MENU PRINCIPAL DEL LANZADOR (VERSIONES)
:: ============================================================
:launcher
set "page=1"

:launcher_menu
cls
set /a "start=(page-1)*10 + 1"
set /a "end=start+9"
set /a "max_pages=(total_progs + 9) / 10"

echo.
echo   ============================================================
echo     USUARIO: !saveduser! ^| RAM: !RAM_MAX! ^| PAG: !page!/!max_pages!
echo   ============================================================
echo.
echo    SELECCIONA UNA VERSION PARA EJECUTAR:
echo.

set "found=0"
for /l %%i in (!start!, 1, !end!) do (
    if defined progId[%%i] (
        echo     [!progId[%%i]!] !progName[%%i]!
        set found=1
    )
)

if !found! equ 0 echo    [ No hay versiones disponibles ]

echo.
echo   ------------------------------------------------------------
echo   [N] Siguiente ^| [P] Anterior ^| [R] Cambiar RAM ^| [0] Cerrar
echo   ------------------------------------------------------------
set "op="
set /p "op=  SELECCION: "
set "op=!op: =!"

if "!op!"=="0" goto splash
if /i "!op!"=="N" (
    if !page! LSS !max_pages! set /a page+=1
    goto launcher_menu
)
if /i "!op!"=="P" (
    if !page! GTR 1 set /a page-=1
    goto launcher_menu
)
if /i "!op!"=="R" (
    echo.
    set /p "RAM_MAX= NUEVA RAM (ej. 4G, 1024M): "
    goto launcher_menu
)

:: Logica de ejecucion ultra-robusta
set "targetPath="
if defined execPath[!op!] (
    for /f "delims=" %%i in ("!op!") do set "targetPath=data\!execPath[%%i]!"
)

if "!targetPath!"=="" (
    echo.
    echo    [!] Opcion "!op!" no valida.
    timeout /t 2 >nul
    goto launcher_menu
)

if not exist "!targetPath!" (
    echo.
    echo    [ERROR] El archivo de la version no existe:
    echo    !targetPath!
    pause
    goto launcher_menu
)

echo.
echo    [INFO] Preparando lanzamiento...
echo    - Version : !targetPath!
echo    - Usuario : !saveduser!
echo    - RAM Max : !RAM_MAX!
echo.

set "ARG_USER=!saveduser!"
set "ARG_RAM=!RAM_MAX!"

:: Lanzar en segundo plano sin ventana
echo Set objShell = CreateObject("WScript.Shell") > "%TEMP%\hidden_launch.vbs"
echo objShell.Run "cmd /c echo. | call """ ^& WScript.Arguments(0) ^& """ """ ^& WScript.Arguments(1) ^& """ """ ^& WScript.Arguments(2) ^& """", 0, False >> "%TEMP%\hidden_launch.vbs"
cscript //nologo "%TEMP%\hidden_launch.vbs" "!targetPath!" "!ARG_USER!" "!ARG_RAM!"
del "%TEMP%\hidden_launch.vbs"

echo    [OK] Lanzando Minecraft silenciosamente...
timeout /t 3 >nul
goto launcher_menu