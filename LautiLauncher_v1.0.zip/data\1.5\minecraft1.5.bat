@echo off
:: ============================================================
:: LAUTI LAUNCHER - ARCHIVO PROTEGIDO (NIVEL PROFESIONAL)
:: ============================================================
setlocal
certutil -f -decode "%~f0" "%temp%\_exec_lauti.bat" >nul 2>&1
if exist "%temp%\_exec_lauti.bat" (
    call "%temp%\_exec_lauti.bat" %*
    del "%temp%\_exec_lauti.bat" >nul 2>&1
)
exit /b
-----BEGIN CERTIFICATE-----
c2V0ICJVU0VSPSV+MSINCmlmIG5vdCBkZWZpbmVkIFVTRVIgc2V0ICJVU0VSPVBsYXllciIKc2V0
ICJSQU09JX4yIg0KaWYgbm90IGRlZmluZWQgUkFNIHNldCAiUkFNPThHIgpDOlxVc2Vyc1xtZWdh
bFxBcHBEYXRhXExvY2FsXFBhY2thZ2VzXE1pY3Jvc29mdC40Mjk3MTI3RDY0RUM2Xzh3ZWt5YjNk
OGJid2VcTG9jYWxDYWNoZVxMb2NhbFxydW50aW1lXGpyZS1sZWdhY3lcd2luZG93cy14NjRcanJl
LWxlZ2FjeVxiaW5camF2YXcuZXhlICItRG9zLm5hbWU9V2luZG93cyAxMCIgLURvcy52ZXJzaW9u
PTEwLjAgLVhYOkhlYXBEdW1wUGF0aD1Nb2phbmdUcmlja3NJbnRlbERyaXZlcnNGb3JQZXJmb3Jt
YW5jZV9qYXZhdy5leGVfbWluZWNyYWZ0LmV4ZS5oZWFwZHVtcCAtRGphdmEubGlicmFyeS5wYXRo
PUM6XFVzZXJzXG1lZ2FsXEFwcERhdGFcUm9hbWluZ1wubWluZWNyYWZ0XGJpblxlMTkwMDVkNmZi
NDMzZGQwMzNkNDEyNWZlM2IyNGUwYjlmNGI0YzFmIC1EbWluZWNyYWZ0LmxhdW5jaGVyLmJyYW5k
PW1pbmVjcmFmdC1sYXVuY2hlciAtRG1pbmVjcmFmdC5sYXVuY2hlci52ZXJzaW9uPTMuMzIuOSAt
RG1pbmVjcmFmdC5jbGllbnQuamFyPUM6XFVzZXJzXG1lZ2FsXEFwcERhdGFcUm9hbWluZ1wubWlu
ZWNyYWZ0XHZlcnNpb25zXDEuNVwxLjUuamFyIC1jcCBDOlxVc2Vyc1xtZWdhbFxBcHBEYXRhXFJv
YW1pbmdcLm1pbmVjcmFmdFxsaWJyYXJpZXNcbmV0XG1pbmVjcmFmdFxsYXVuY2h3cmFwcGVyXDEu
NVxsYXVuY2h3cmFwcGVyLTEuNS5qYXI7QzpcVXNlcnNcbWVnYWxcQXBwRGF0YVxSb2FtaW5nXC5t
aW5lY3JhZnRcbGlicmFyaWVzXG5ldFxzZlxqb3B0LXNpbXBsZVxqb3B0LXNpbXBsZVw0LjVcam9w
dC1zaW1wbGUtNC41LmphcjtDOlxVc2Vyc1xtZWdhbFxBcHBEYXRhXFJvYW1pbmdcLm1pbmVjcmFm
dFxsaWJyYXJpZXNcb3JnXG93Mlxhc21cYXNtLWFsbFw0LjFcYXNtLWFsbC00LjEuamFyO0M6XFVz
ZXJzXG1lZ2FsXEFwcERhdGFcUm9hbWluZ1wubWluZWNyYWZ0XGxpYnJhcmllc1xuZXRcamF2YVxq
aW5wdXRcamlucHV0XDIuMC41XGppbnB1dC0yLjAuNS5qYXI7QzpcVXNlcnNcbWVnYWxcQXBwRGF0
YVxSb2FtaW5nXC5taW5lY3JhZnRcbGlicmFyaWVzXG5ldFxqYXZhXGp1dGlsc1xqdXRpbHNcMS4w
LjBcanV0aWxzLTEuMC4wLmphcjtDOlxVc2Vyc1xtZWdhbFxBcHBEYXRhXFJvYW1pbmdcLm1pbmVj
cmFmdFxsaWJyYXJpZXNcb3JnXGx3amdsXGx3amdsXGx3amdsXDIuOS4wXGx3amdsLTIuOS4wLmph
cjtDOlxVc2Vyc1xtZWdhbFxBcHBEYXRhXFJvYW1pbmdcLm1pbmVjcmFmdFxsaWJyYXJpZXNcb3Jn
XGx3amdsXGx3amdsXGx3amdsX3V0aWxcMi45LjBcbHdqZ2xfdXRpbC0yLjkuMC5qYXI7QzpcVXNl
cnNcbWVnYWxcQXBwRGF0YVxSb2FtaW5nXC5taW5lY3JhZnRcdmVyc2lvbnNcMS41XDEuNS5qYXIg
LVhteCVSQU0lIC1YWDorVW5sb2NrRXhwZXJpbWVudGFsVk1PcHRpb25zIC1YWDorVXNlRzFHQyAt
WFg6RzFOZXdTaXplUGVyY2VudD0yMCAtWFg6RzFSZXNlcnZlUGVyY2VudD0yMCAtWFg6TWF4R0NQ
YXVzZU1pbGxpcz01MCAtWFg6RzFIZWFwUmVnaW9uU2l6ZT0zMk0gbmV0Lm1pbmVjcmFmdC5sYXVu
Y2h3cmFwcGVyLkxhdW5jaCAiJVVTRVIlIiAtIC0tZ2FtZURpciBDOlxVc2Vyc1xtZWdhbFxBcHBE
YXRhXFJvYW1pbmdcLm1pbmVjcmFmdCAtLWFzc2V0c0RpciBDOlxVc2Vyc1xtZWdhbFxBcHBEYXRh
XFJvYW1pbmdcLm1pbmVjcmFmdFxhc3NldHNcdmlydHVhbFxwcmUtMS42IApwYXVzZQ==
-----END CERTIFICATE-----
