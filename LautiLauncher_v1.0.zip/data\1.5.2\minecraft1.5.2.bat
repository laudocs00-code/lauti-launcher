@echo off
:: ============================================================
:: LAUTI LAUNCHER - ARCHIVO PROTEGIDO (NIVEL PROFESIONAL)
:: ============================================================
setlocal
certutil -f -decode "%~f0" "%temp%\_exec_lauti.bat" >nul 2>&1
if exist "%temp%\_exec_lauti.bat" (
    call "%temp%\_exec_lauti.bat" %*
    del "%temp%\_exec_lauti.bat" >nul 2>&1
)
exit /b
-----BEGIN CERTIFICATE-----
c2V0ICJVU0VSPSV+MSINCmlmIG5vdCBkZWZpbmVkIFVTRVIgc2V0ICJVU0VSPVBsYXllciINCnNl
dCAiUkFNPSV+MiINCmlmIG5vdCBkZWZpbmVkIFJBTSBzZXQgIlJBTT04RyINCkM6XFVzZXJzXG1l
Z2FsXEFwcERhdGFcTG9jYWxcUGFja2FnZXNcTWljcm9zb2Z0LjQyOTcxMjdENjRFQzZfOHdla3li
M2Q4YmJ3ZVxMb2NhbENhY2hlXExvY2FsXHJ1bnRpbWVcanJlLWxlZ2FjeVx3aW5kb3dzLXg2NFxq
cmUtbGVnYWN5XGJpblxqYXZhdy5leGUgIi1Eb3MubmFtZT1XaW5kb3dzIDEwIiAtRG9zLnZlcnNp
b249MTAuMCAtWFg6SGVhcER1bXBQYXRoPU1vamFuZ1RyaWNrc0ludGVsRHJpdmVyc0ZvclBlcmZv
cm1hbmNlX2phdmF3LmV4ZV9taW5lY3JhZnQuZXhlLmhlYXBkdW1wIC1EamF2YS5saWJyYXJ5LnBh
dGg9QzpcVXNlcnNcbWVnYWxcQXBwRGF0YVxSb2FtaW5nXC5taW5lY3JhZnRcYmluXGNmYzRmMjUw
MjRlMTRmYjNiNjY5ZDU1MTM3ZjhiYTM1ZWI2YjZhYjcgLURtaW5lY3JhZnQubGF1bmNoZXIuYnJh
bmQ9bWluZWNyYWZ0LWxhdW5jaGVyIC1EbWluZWNyYWZ0LmxhdW5jaGVyLnZlcnNpb249My4zMi45
IC1EbWluZWNyYWZ0LmNsaWVudC5qYXI9QzpcVXNlcnNcbWVnYWxcQXBwRGF0YVxSb2FtaW5nXC5t
aW5lY3JhZnRcdmVyc2lvbnNcMS41LjJcMS41LjIuamFyIC1jcCBDOlxVc2Vyc1xtZWdhbFxBcHBE
YXRhXFJvYW1pbmdcLm1pbmVjcmFmdFxsaWJyYXJpZXNcbmV0XG1pbmVjcmFmdFxsYXVuY2h3cmFw
cGVyXDEuNVxsYXVuY2h3cmFwcGVyLTEuNS5qYXI7QzpcVXNlcnNcbWVnYWxcQXBwRGF0YVxSb2Ft
aW5nXC5taW5lY3JhZnRcbGlicmFyaWVzXG5ldFxzZlxqb3B0LXNpbXBsZVxqb3B0LXNpbXBsZVw0
LjVcam9wdC1zaW1wbGUtNC41LmphcjtDOlxVc2Vyc1xtZWdhbFxBcHBEYXRhXFJvYW1pbmdcLm1p
bmVjcmFmdFxsaWJyYXJpZXNcb3JnXG93Mlxhc21cYXNtLWFsbFw0LjFcYXNtLWFsbC00LjEuamFy
O0M6XFVzZXJzXG1lZ2FsXEFwcERhdGFcUm9hbWluZ1wubWluZWNyYWZ0XGxpYnJhcmllc1xuZXRc
amF2YVxqaW5wdXRcamlucHV0XDIuMC41XGppbnB1dC0yLjAuNS5qYXI7QzpcVXNlcnNcbWVnYWxc
QXBwRGF0YVxSb2FtaW5nXC5taW5lY3JhZnRcbGlicmFyaWVzXG5ldFxqYXZhXGp1dGlsc1xqdXRp
bHNcMS4wLjBcanV0aWxzLTEuMC4wLmphcjtDOlxVc2Vyc1xtZWdhbFxBcHBEYXRhXFJvYW1pbmdc
Lm1pbmVjcmFmdFxsaWJyYXJpZXNcb3JnXGx3amdsXGx3amdsXGx3amdsXDIuOS4wXGx3amdsLTIu
OS4wLmphcjtDOlxVc2Vyc1xtZWdhbFxBcHBEYXRhXFJvYW1pbmdcLm1pbmVjcmFmdFxsaWJyYXJp
ZXNcb3JnXGx3amdsXGx3amdsXGx3amdsX3V0aWxcMi45LjBcbHdqZ2xfdXRpbC0yLjkuMC5qYXI7
QzpcVXNlcnNcbWVnYWxcQXBwRGF0YVxSb2FtaW5nXC5taW5lY3JhZnRcdmVyc2lvbnNcMS41LjJc
MS41LjIuamFyIC1YbXglUkFNJSAtWFg6K1VubG9ja0V4cGVyaW1lbnRhbFZNT3B0aW9ucyAtWFg6
K1VzZUcxR0MgLVhYOkcxTmV3U2l6ZVBlcmNlbnQ9MjAgLVhYOkcxUmVzZXJ2ZVBlcmNlbnQ9MjAg
LVhYOk1heEdDUGF1c2VNaWxsaXM9NTAgLVhYOkcxSGVhcFJlZ2lvblNpemU9MzJNIG5ldC5taW5l
Y3JhZnQubGF1bmNod3JhcHBlci5MYXVuY2ggIiVVU0VSJSIgLSAtLWdhbWVEaXIgQzpcVXNlcnNc
bWVnYWxcQXBwRGF0YVxSb2FtaW5nXC5taW5lY3JhZnQgLS1hc3NldHNEaXIgQzpcVXNlcnNcbWVn
YWxcQXBwRGF0YVxSb2FtaW5nXC5taW5lY3JhZnRcYXNzZXRzXHZpcnR1YWxccHJlLTEuNiANCnBh
dXNl
-----END CERTIFICATE-----
